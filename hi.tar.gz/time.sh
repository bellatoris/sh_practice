#!/bin/bash

echo "현재 시간은 ..."
date

echo "모든 사용자는 ..."
who

echo "접속한 이후의 경과 시간은 ..."
uptime
