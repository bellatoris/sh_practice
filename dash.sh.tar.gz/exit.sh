#!/bin/bash

echo hello
echo $?

sadfsd
echo $?

echo
exit 113
